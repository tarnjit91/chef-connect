<?php
$Sname='localhost';
$Uname='root';
$Password='';
$Dname='chef';

$connect=mysqli_connect($Sname,$Uname,$Password,$Dname);
if(!$connect)
{
  die('Error Connecting to Database');
}
echo 'You have Connected Successfully';
?>