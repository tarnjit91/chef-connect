<?php
include('C:\xampp\htdocs\Chef Php\Database\Connection.php');
if(isset($_POST['Sub1']))
{
 $Ufname=$_POST['fname'];
 $Ulname=$_POST['lname'];
 $Email=$_POST['email'];
 $Passw=$_POST['psw'];
 $Age=$_POST['age'];
 $Gen=$_POST['Gender'];
 $type=$_POST['Types'];
 $sd='Cheflogin.php';

	if($Ufname!=''||$Ulname!=''||$Email!=''||$Passw!=''||$Age!=''||$Gen!=''||$type!='')
	{
		$Ms=mysqli_query($connect,"Select * from Chef1 where Email_Id='$Email'");
		if(mysqli_num_rows($Ms)>0){
			echo "<script>
			alert('Email Already Defined');
			</script>";
		}
		else{
		foreach($_POST['Types'] as $type)
		{
			mysqli_query($connect,"Insert into Chef1(First,Last,Email_Id,Password,Age,Gender,Typeofchef) values ('$Ufname','$Ulname','$Email','$Passw','$Age','$Gen','$type')");
			echo("Register Successfull");
		}
		}
	}
	else 	
	{
	 	echo "<p>Fill all the fields</p>";
	}
}
mysqli_close($connect);
?>