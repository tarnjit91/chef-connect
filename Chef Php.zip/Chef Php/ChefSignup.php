<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>register</title>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
input[type=text], input[type=password],input[type=email] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}
	.cs.input[type=password]{
		width:50%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-b
	}
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 50%;
}

button:hover {
    opacity: 0.8;
}
.imgcontainer {
    text-align: center;
    margin: 20px 0 12px 0;
    position: relative;
}

img.avatar {
    width: 20%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

.animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
</style>
</head>
<body>

<h2 align="center">Register Here</h2>
    <form action="Files/SignuP.php" method="post">
    <div class="container">
      <label for="fname"><strong>Firstname<br>
        <br>
      </strong></label>
      <input type="text" placeholder="Enter Firstname" name="fname" required>
		<label for="lname"><b>Lastname</b></label>
      <input type="text" placeholder="Enter Lastname" name="lname" required>
		<br>
<label for="email"><b>Email</b></label>
		<br>
      <input type="email" placeholder="Enter email" name="email" required>
		<br>
      <label for="psw"><b>Password</b></label><br>
      <input type="password" class="ps" placeholder="Enter Password" name="psw" required>
		<br>
		<label for="age"><b>Age</b></label><br>
		<br>
	  <input type="date" placeholder="Enter " name="age" required><br>
		<label for="Gender"><b>Gender</b></label>
      <input type="radio" name="Gender" value="male">Male
	    <input type="radio" name="Gender" value="Female">Female
		<br>
		<label for="TypesOfChef"><b>Type of Chef</b></label><br>
		<select name="Types[]">
		<option>Executive_Chef</option>
		<option>Head_Chef</option>
		<option>Sous_Chef</option>
	    <option>Line_Chef</option>
		<option>Junior_Chef</option>
		<option>Kitchen_Porter</option>
		<option>Executive_Chef</option>
		<option>Executive_Chef</option>
		<option>Executive_Chef</option>
		<option>Junior_Chef</option>
		<option>Kitchen_Porter</option>
		<option>Dishwasher</option>
		<option>Pastry_Chef</option>
		<option>Saute_Chef</option>
		<option>Roast_Chef</option>
		<option>Pantry_Chef</option>
		<option>Butcher_Chef</option>
		<option>Swing_Cook</option>
		</select>
		<br>
      <button type="submit" name="Sub1">Register</button>
</div>
	</form>
</body>
</html>
